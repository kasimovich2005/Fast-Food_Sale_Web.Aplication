import dotenv from "dotenv";
dotenv.config(); // 👉 .env faylni shu yerda yuklaymiz

import OrderModel from "../models/orderModel.js";
import UserModel from "../models/userModel.js";
import Stripe from "stripe";
import { sendOrderToTelegram } from "../telegramService.js";


// 👉 Stripe endi .env yuklangandan keyin ishlaydi
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);


// ===============================
// 1) CREATE CHECKOUT SESSION
// ===============================
const createSession = async (req, res) => {
  try {
    const userId = req.userID; 
    const { cartItems, foodList, deliveryAddress } = req.body;  
    
    if (!cartItems || Object.keys(cartItems).length === 0) {
      return res.status(400).json({ success: false, message: "Cart bo'sh" });
    }

    const line_items = Object.keys(cartItems).map((itemId) => {
      const product = foodList.find((f) => f._id === itemId);
      return {
        price_data: {
          currency: "usd",
          product_data: { name: product.name },
          unit_amount: product.price * 100,
        },
        quantity: cartItems[itemId],
      };
    });

    const totalAmount = Object.keys(cartItems).reduce((sum, itemId) => {
      const product = foodList.find((f) => f._id === itemId);
      return sum + product.price * cartItems[itemId];
    }, 0);

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items,
      mode: "payment",
      success_url: `${process.env.CLIENT_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.CLIENT_URL}/cancel`,
    });

    const order = new OrderModel({
      user: userId,
      items: Object.keys(cartItems).map((id) => {
        const product = foodList.find((f) => f._id === id);
        return {
          itemId: id,
          name: product.name,
          price: product.price,
          quantity: cartItems[id],
        };
      }),
      totalAmount,
      paymentStatus: "pending",
      stripeSessionId: session.id,
      deliveryAddress,
    });

    await order.save();

    console.log("create")

    // Yaratilgan orderni telegramga yuborish
    await sendOrderToTelegram({
      customerName: deliveryAddress?.firstName || "Noma'lum",
      phone: deliveryAddress?.phone || "Yo‘q",
      address: deliveryAddress?.street || "Yo‘q",
      // city: deliveryAddress?.city || "Yo'q",
      items: order.items.map(item => ({
        name: item.name,
        qty: item.quantity
      })),
      total: order.totalAmount
    });

    res.json({ url: session.url });
  } catch (error) {
    console.log("Stripe checkout xatoligi:", error);
    res.status(500).json({ success: false, message: "Xatolik" });
  }
};



// ===============================
// 2) GET ALL ORDERS (ADMIN)
// ===============================
const getAllOrders = async (req, res) => {
  try {
    const orders = await OrderModel.find()
      .populate("user", "name email")
      .sort({ createdAt: -1 });

    res.json({ success: true, orders });
  } catch (error) {
    console.log("Admin order list xatoligi:", error);
    res.status(500).json({ success: false, message: "Buyurtmalarni olishda xatolik" });
  }
};



// ===============================
// 3) GET ORDER BY ID (DETAIL)
// ===============================
const getOrderDetails = async (req, res) => {
  try {
    const orderId = req.params.id;

    const order = await OrderModel.findById(orderId)
      .populate("user", "name email");

    if (!order)
      return res.status(404).json({ success: false, message: "Order topilmadi" });

    res.json({ success: true, order });
  } catch (error) {
    console.log("Order detail xatoligi:", error);
    res.status(500).json({ success: false, message: "Order detail xatolik" });
  }
};



// ===============================
// 4) UPDATE ORDER STATUS (ADMIN)
// ===============================
const updateOrderStatus = async (req, res) => {
  try {
    const { orderId } = req.params;
    const { paymentStatus } = req.body;

    const updated = await OrderModel.findByIdAndUpdate(
      orderId,
      { paymentStatus },
      { new: true }
    );

    if (!updated)
      return res.status(404).json({ success: false, message: "Order topilmadi" });

    res.json({
      success: true,
      message: "Status yangilandi",
      order: updated,
    });
  } catch (error) {
    console.log("Status update xatoligi:", error);
    res.status(500).json({ success: false, message: "Status o'zgartirish xatolik" });
  }
};



// ===============================
// 5) GET ORDER BY STRIPE SESSION ID
// ===============================
const getOrderBySession = async (req, res) => {
  try {
    const sessionId = req.params.sessionId;

    const order = await OrderModel.findOne({ stripeSessionId: sessionId });

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Session ID bo‘yicha order topilmadi",
      });
    }

    res.json(order);
  } catch (error) {
    console.log("Session ID bo‘yicha order olish xatosi:", error);
    res.status(500).json({ success: false, message: "Xatolik" });
  }
};



// ===============================
// 6) PAYMENT SUCCESS AUTOCONFIRM
// ===============================
const confirmPayment = async (sessionId) => {
  try {
    await OrderModel.findOneAndUpdate(
      { stripeSessionId: sessionId },
      { paymentStatus: "paid" }
    );
  } catch (error) {
    console.log("Payment holatini yangilash xatoligi:", error);
  }
};

export const createOrder = async (req, res) => {
  try {
    const newOrder = await OrderModel.create(req.body);

    res.status(201).json({
      success: true,
      message: "Order created",
      order: newOrder,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ success: false });
  }
};


export {
  createSession,
  getAllOrders,
  updateOrderStatus,
  getOrderDetails,
  getOrderBySession,
  confirmPayment,
};
