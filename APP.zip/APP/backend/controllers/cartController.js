// import userModel from "../models/userModel.js"

// // add items to user cart

// const addToCart = async (req, res) => {
//     try {
//         let userData = await userModel.findOne({_id:req.body.userId})
//         let cartData = await userData.cartData;
//         if(!cartData[req.body.item])
//         {
//             cartData[req.body.item] = 1
//         }
//         else
//         {
//             cartData[req.body.itemId] += 1;
//         }
//         await userModel.findByIdAndUpdate(req.body.userId,{cartData});
//         res.json({success:true,message:"Add To Cart"})
//     } catch (error) {
//         console.log(error);
//         res.json({success:false,message:X})
//     }

// }

// // remove items from user cart

// const removeFromCart = async (req, res) => {

// }

// // fetch user cart data 

// const getCart = async (req, res) => {

// }


// export {addToCart,removeFromCart,getCart}







import userModel from "../models/userModel.js";
// =========================
// Add item to cart
// =========================
const addToCart = async (req, res) => {
    try {
        const userId = req.userID; // token orqali olinadi
        const itemId = req.body.itemId;

        if (!itemId) {
            return res.status(400).json({success:false, message:"itemId required"});
        }

        const userData = await userModel.findById(userId);
        if (!userData) return res.status(404).json({success:false,message:"User not found"});

        let cartData = userData.cartData || {};

        if (!cartData[itemId]) {
            cartData[itemId] = 1;
        } else {
            cartData[itemId] += 1;
        }

        userData.cartData = cartData;
        await userData.save();

        res.json({success:true,message:"Item added to cart", cartData});
    } catch (error) {
        console.log("Cart add xatoligi:", error);
        res.status(500).json({success:false,message:"Xatolik"});
    }
};

// // remove items from user cart
// const removeFromCart = async (req, res) => {
//   try {
//     let userData = await userModel.findById(req.body.userId);
//     let cartData = await userData.cartData;
//     if (cartData[req.body.itemId]>0){
//         cartData[req.body.itemId] -= 1;
//     }
//     await userModel.findByIdAndUpdate(req.body.userId,{cartData});
//     res.json({success:true,message:"Remove From Cart "})
//   } catch (error) {
//     console.log(error);
//     res.json({success:false, message:"Error"})
//   }
// }
const removeFromCart = async (req, res) => {
    try {
        const userId = req.userID; // token orqali olinadi
        const itemId = req.body.itemId;

        if (!itemId) return res.status(400).json({success:false,message:"itemId required"});

        const userData = await userModel.findById(userId);
        if (!userData) return res.status(404).json({success:false,message:"User not found"});

        let cartData = userData.cartData || {};

        if (!cartData[itemId]) {
            return res.json({success:false,message:"Item not in cart"});
        }

        delete cartData[itemId];

        userData.cartData = cartData;
        await userData.save();

        res.json({success:true,message:"Item removed from cart", cartData});
    } catch (error) {
        console.log("Cart remove xatoligi:", error);
        res.status(500).json({success:false,message:"Xatolik"});
    }
};

const clearFromCart = async (req, res) => {
    try {
        const userId = req.userID; // token orqali olinadi
        const itemId = req.body.itemId;

        if (!itemId) return res.status(400).json({success:false,message:"itemId required"});

        const userData = await userModel.findById(userId);
        if (!userData) return res.status(404).json({success:false,message:"User not found"});

        let cartData = userData.cartData || {};

        if (!cartData[itemId]) {
            return res.json({success:false,message:"Item not in cart"});
        }

        delete cartData[itemId];

        userData.cartData = {};
        await userData.save();

        res.json({success:true,message:"Item removed from cart", cartData});
    } catch (error) {
        console.log("Cart remove xatoligi:", error);
        res.status(500).json({success:false,message:"Xatolik"});
    }
};

// =========================
// Get cart data
// =========================
const getCart = async (req, res) => {
    try {
        const userId = req.userID; // token orqali olinadi

        const userData = await userModel.findById(userId);
        if (!userData) return res.status(404).json({success:false,message:"User not found"});

        const cartData = userData.cartData || {};
        res.json({success:true, cartData});
    } catch (error) {
        console.log("Cart fetch xatoligi:", error);
        res.status(500).json({success:false,message:"Xatolik"});
    }
};

export { addToCart, removeFromCart, getCart, clearFromCart };