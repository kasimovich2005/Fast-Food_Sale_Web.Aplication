import axios from "axios";

export const sendOrderToTelegram = async (order) => {
  try {
    console.log("📤 Telegram function ishladi");

    const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
    const CHAT_ID = process.env.TELEGRAM_CHAT_ID;

    console.log("BOT:", BOT_TOKEN);
    console.log("CHAT:", CHAT_ID);

    const message =
      `🍔 <b>Yangi Buyurtma!</b>\n\n` +
      `👤 Ism: ${order.customerName}\n` +
      `📞 Telefon: ${order.phone}\n` +
      `📍 Manzil: ${order.address}\n\n` +
      `🛒 Buyurtma:\n` +
      order.items.map(item => `- ${item.name} x${item.qty || item.quantity}`).join("\n") +
      `\n\n💵 <b>Jami:</b> $${order.total}`;

    console.log(message);

    const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;

    await axios.post(url, {
      chat_id: CHAT_ID,
      text: message,
      parse_mode: "HTML"
    });

    console.log("✅ Telegramga yuborildi");
  } catch (err) {
    console.log("❌ Telegram xatolik:", err.response?.data || err.message);
  }
};
