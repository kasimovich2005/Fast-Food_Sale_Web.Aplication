import express from "express";
import { 
  createSession, 
  getAllOrders, 
  updateOrderStatus, 
  getOrderDetails,
  getOrderBySession
} from "../controllers/orderController.js";
import authMiddleware from "../middleware/auth.js";

const orderRouter = express.Router();

orderRouter.post("/create-checkout-session", authMiddleware, createSession);
orderRouter.get("/all", getAllOrders);
orderRouter.get("/:id", getOrderDetails);
orderRouter.get("/by-session/:sessionId", getOrderBySession);  // ⭐ YANGI
orderRouter.put("/update-status/:orderId", updateOrderStatus);

export default orderRouter;
