// import express from "express"
// import FoodModel from "../models/foodModel.js";
// import mongoose from "mongoose"; // ✅ to‘g‘ri

// import { addFood } from "../controllers/foodController.js"
// import multer from "multer"

// const foodRouter = express.Router();


// foodRouter.post()







// export default foodRouter;
















import express from "express";
import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";
import { addFood, listFood, removeFood } from "../controllers/foodController.js";

// Router
const foodRouter = express.Router();

// === Multer config (image upload) ===
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "../uploads"));
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  },
});

const upload = multer({ storage });

// === ROUTES ===

// Food qo‘shish (rasm bilan)
foodRouter.post("/add", upload.single("image"), addFood);

foodRouter.get("/list",listFood);
foodRouter.post("/remove", removeFood);

export default foodRouter;
