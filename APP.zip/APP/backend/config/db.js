import mongoose from "mongoose";
 export const connectDB = async () => {
    await mongoose.connect('mongodb+srv://greatstack:33858627@cluster0.7umtoe2.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
    .then(()=>console.log("DB Connected"));


const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URL);
    console.log("MongoDB connected successfully");
  } catch (error) {
    console.log("DB Error:", error);
    process.exit(1);
  }
};

}

export default connectDB;
