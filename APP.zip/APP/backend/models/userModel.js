// import mongoose from "mongoose"

// const userSchema = new mongoose.Schema({
//     name:{type:String, required:true},
//     email:{type:String, required:true, unique:true},
//     password:{type:String, required:true},
//     cardData:{type:Object, default:{}}
// },{minimize:false})

// const userModel = mongoose.model.user || mongoose.model("user", userSchema);
// export default userModel;


import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    cardData: { type: Object, default: {} }
}, { minimize: false });

// ❌ eski: mongoose.model.user
// ✅ to‘g‘ri: mongoose.models.User
const userModel = mongoose.models.User || mongoose.model("User", userSchema);

export default userModel;
