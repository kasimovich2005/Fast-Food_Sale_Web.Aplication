import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";

const OrderDetail = () => {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const url = "http://localhost:4000";
  const token = localStorage.getItem("token");

  useEffect(() => {
    const fetchOrderDetail = async () => {
      try {
        const res = await axios.get(`${url}/api/orders/${id}`, {
          headers: { token },
        });
        setOrder(res.data.order);
      } catch (error) {
        console.log("Order detail olishda xato:", error);
      }
    };
    fetchOrderDetail();
  }, [id]);


////////////////////

///////////////////
  if (!order) return <p>Loading...</p>;

  return (
    <div className="order-detail">
      <h2>Order Detail: {order._id}</h2>
      <p><b>User:</b> {order.user?.name} ({order.user?.email})</p>
      <p><b>Payment Status:</b> {order?.paymentStatus}</p>
      <p><b>Total Amount:</b> ${order?.totalAmount}</p>
      <h3>Delivery Address</h3>
      <p>{order?.deliveryAddress?.firstName} {order?.deliveryAddress?.lastName}</p>
      <p>{order?.deliveryAddress?.street}, {order?.deliveryAddress?.city}, {order?.deliveryAddress?.state}</p>
      <p>{order?.deliveryAddress?.zip}, {order?.deliveryAddress?.country}</p>
      <p>Phone: {order?.deliveryAddress?.phone}</p>
      <h3>Items</h3>
      <ul>
        {order.items.map((item) => (
          <li key={item.itemId}>
            {item.name} x {item.quantity} = ${item.price * item.quantity}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default OrderDetail;
