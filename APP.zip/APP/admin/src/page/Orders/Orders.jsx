import './Orders.css'
import React, { useEffect, useState, useContext } from "react";
import axios from "axios";

const Orders = () => {
  const [orders, setOrders] = useState([]);

  const fetchOrders = async () => {
    try {
      const res = await axios.get(`http://localhost:4000/api/orders/all`, {
        headers: {
          token: localStorage.getItem("token"),
        }
      });
      setOrders(res.data.orders);
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h2>All Orders</h2>
      <table border="1" cellPadding="10" width="100%">
        <thead>
          <tr>
            <th>User</th>
            <th>Total</th>
            <th>Status</th>
            <th>Date</th>
            <th>Details</th>
          </tr>
        </thead>

        <tbody>
          {orders.map((o) => (
            <tr key={o._id}>
              <td data-label="User">{o.user?.email}</td>
              <td data-label="Total">${o.totalAmount}</td>
              <td data-label="Status">{o.paymentStatus}</td>
              <td data-label="Date">{new Date(o.createdAt).toLocaleString()}</td>
              <td>
                <a className="open-btn" href={`/order/${o._id}`}>
                  Open
                </a>
              </td>
            </tr>
          ))}
        </tbody>

      </table>
    </div>
  );
};

export default Orders;