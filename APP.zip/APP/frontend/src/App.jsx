// import { useState } from 'react'



// import React from 'react'
// import Navbar from './components/Navbar/Navbar'
// import { Route, Routes } from 'react-router-dom'
// import Home from './pages/Home/Home'
// import Cart from './pages/Cart/Card'
// import PlaceOrder from './pages/PlaceOrder/PlaceOrder'
// import Footer from './components/Footer/Footer'
// import LoginPopup from './components/LoginPopup/LoginPopup'
// const App = () => {

//   const [showLogin,setShowLogin] = useState(false)

//   return (
//     <>
//     {showLogin?<LoginPopup setShowLogin={setShowLogin}/>:<></>}
//       <div className='app'>

//         <Navbar setShowLogin={setShowLogin} />

//         <Routes>
//           < Route path='/' element={<Home />} />
//           < Route path='/cart' element={<Cart />} />
//           <Route path='/order' element={<PlaceOrder />} />
//         </Routes>

//       </div>

//       <Footer />
//     </>
//   )
// }

// export default App




import { useState } from 'react'
import React from 'react'
import Navbar from './components/Navbar/Navbar'
import { Route, Routes } from 'react-router-dom'
import Home from './pages/Home/Home'
import Cart from './pages/Cart/Card'
import PlaceOrder from './pages/PlaceOrder/PlaceOrder'
import Footer from './components/Footer/Footer'
import LoginPopup from './components/LoginPopup/LoginPopup'
import StoreContextProvider from './context/StoreContext' // Bu qatorni qo'shing
import Success from './pages/Success'
import MyOrders from './pages/MyOrders/MyOrders'

const App = () => {
  const [showLogin, setShowLogin] = useState(false)

  return (
    <>
      <StoreContextProvider> {/* StoreContextProvider ni qo'shing */}
        {showLogin ? <LoginPopup setShowLogin={setShowLogin}/> : <></>}
        <div className='app'>
          <Navbar setShowLogin={setShowLogin} />

          <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/cart' element={<Cart />} />
            <Route path='/order' element={<PlaceOrder />} />
            <Route path='/success' element={<Success/>} />
            <Route path='/myorders' element={<MyOrders/>}/>
          </Routes>
        </div>

        <Footer />
      </StoreContextProvider> {/* StoreContextProvider ni yopish */}
    </>
  )
}

export default App