import React, { useContext } from 'react'
import './Card.css'
import { StoreContext } from '../../context/StoreContext'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'

const Card = () => {
  const navigate = useNavigate()

  // 🔴 MUAMMO SHU YERDA EDI — addToCart & removeFromCart yo‘q edi
  const {
    cartItems,
    food_list,
    getTotalCartAmount,
    url,
    token,
    addToCart,
    removeFromCart,
    clearFromCart
  } = useContext(StoreContext)

  const handleCheckout = async () => {
    try {
      const res = await axios.post(
        `${url}/api/orders/create-checkout-session`,
        { cartItems, foodList: food_list },
        { headers: { token } }
      )
      window.location.href = res.data.url
    } catch (error) {
      console.log("Checkout xatoligi:", error)
    }
  }

  return (
    <div className='cart'>
      <div className="cart-items">
        <div className="cart-items-title">
          <p>Rasm</p>
          <p>Nomi</p>
          <p>Narxi</p>
          <p>Soni</p>
          <p>Jami</p>
          <p>O'chirish</p>
        </div>

        <hr />

        {food_list.map((item) => {
          if (cartItems[item._id] > 0) {
            return (
              <div key={item._id}>
                <div className='cart-items-title cart-items-item'>
                  <img src={`${url}/images/${item.image}`} alt="" />
                  <p>{item.name}</p>
                  <p>${item.price}</p>

                  {/* ➕➖ ISHLAYDIGAN QISMI */}
                  <div className="cart-qty">
                    <button
                      onClick={() => removeFromCart(item._id)}
                      disabled={cartItems[item._id] === 1}
                    >
                      -
                    </button>

                    <span>{cartItems[item._id]}</span>

                    <button onClick={() => addToCart(item._id)}>
                      +
                    </button>
                  </div>

                  <p>${item.price * cartItems[item._id]}</p>

                  <p
                    className="cross"
                    onClick={() => clearFromCart(item._id)}
                  >
                    x
                  </p>
                </div>
                <hr />
              </div>
            )
          }
          return null
        })}
      </div>

      <div className='cart-bottom'>
        <div className="cart-total">
          <h2>Jami Buyurtmalar</h2>

          <div className="cart-total-details">
            <p>Taomning jami narxi</p>
            <p>${getTotalCartAmount()}</p>
          </div>

          <hr />

          <div className="cart-total-details">
            <p>Yetkazib berish</p>
            <p>${getTotalCartAmount() === 0 ? 0 : 2}</p>
          </div>

          <hr />

          <div className="cart-total-details">
            <b>Jami</b>
            <b>
              $
              {getTotalCartAmount() === 0
                ? 0
                : getTotalCartAmount() + 2}
            </b>
          </div>

          <button onClick={() => navigate("/order")}>
            Buyurtma berish uchun
          </button>
        </div>

        <div className="cart-promocode">
          <p>Agar sizda promo-kod bo'lsa, uni shu yerga kiriting</p>
          <div className="cart-promocode-input">
            <input type="text" placeholder="promo code" />
            <button>Tekshirish</button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Card
