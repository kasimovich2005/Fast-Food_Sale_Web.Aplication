import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import { StoreContext } from '../../context/StoreContext';

const MyOrders = () => {
  const { url, token } = useContext(StoreContext);
  const [orders, setOrders] = useState([]);

  const fetchOrders = async () => {
    try {
      const res = await axios.post(
        `${url}/api/order/userorders`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setOrders(res.data.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    if (token) fetchOrders();
  }, [token]);

  return (
    <div>
      <h2>My Orders</h2>
      {orders.length === 0 ? (
        <p>Buyurtmalaringiz yo‘q</p>
      ) : (
        orders.map(order => (
          <div key={order._id} style={{ border: '1px solid #ccc', margin: '10px', padding: '10px' }}>
            <p>Order ID: {order._id}</p>
            <p>Status: {order.paymentStatus}</p>
            <p>Total: ${order.totalAmount}</p>
          </div>
        ))
      )}
    </div>
  );
};

export default MyOrders;
