// import React, { useEffect, useState } from "react";
// import { DotLottieReact } from "@lottiefiles/dotlottie-react";
// import { useSearchParams, useNavigate } from "react-router-dom";
// import './Success.css';

// const Success = () => {
//   const [searchParams] = useSearchParams();
//   const navigate = useNavigate();

//   const sessionId = searchParams.get("session_id");
//   const [order, setOrder] = useState(null);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     if (!sessionId) return;
//     async function fetchOrder() {
//       try {
//         const res = await fetch(
//           `http://localhost:4000/api/orders/by-session/${sessionId}`
//         );
//         const data = await res.json();
//         if (data.success) setOrder(data.order);
//         setLoading(false);
//       } catch (err) {
//         console.log("Error:", err);
//         setLoading(false);
//       }
//     }
//     fetchOrder();
//   }, [sessionId]);

//   if (loading) {
//     return (
//       <div className="success-container">
//         <div className="success-title">Loading your order...</div>
//       </div>
//     );
//   }

//   return (
//     <div className="success-container">

//       <div className="success-animation">
//         <DotLottieReact
//           src="https://lottie.host/00282d0b-aadf-49c4-a59c-08558f2ffcaf/ViI4pAcmES.lottie"
//           loop={false}
//           autoplay
//         />
//       </div>

//       <h1 className="success-title">Buyurtma muvaffaqiyatli bajarildi! 🎉</h1>

//       {order && (
//         <div className="order-card">
//           <h2>🧾 Buyurtma ma’lumotlari</h2>

//           <p><span>Order raqami:</span> <br /> <span style={{color:'#1e40af'}}>#{order._id}</span></p>
//           <p><span>To‘lov holati:</span> <br /> <span style={{color:'#16a34a', textTransform:'capitalize'}}>{order.paymentStatus}</span></p>
//           <p><span>Umumiy summa:</span> <br /> ${order.totalAmount}</p>
//           <p><span>Manzil:</span> <br /> {order.deliveryAddress}</p>

//           <div className="mt-4">
//             <h3 className="text-lg font-semibold mb-2">🍔 Buyurtma tarkibi:</h3>
//             <ul>
//               {order.items.map((item, index) => (
//                 <li key={index}>{item.name} — {item.quantity} x ${item.price}</li>
//               ))}
//             </ul>
//           </div>
//         </div>
//       )}

//       <button
//         onClick={() => navigate("/")}
//         className="success-button"
//       >
//         Bosh sahifaga qaytish
//       </button>
//     </div>
//   );
// };

// export default Success;


















import React, { useEffect, useState } from "react";
import { DotLottieReact } from "@lottiefiles/dotlottie-react";
import { useSearchParams, useNavigate } from "react-router-dom";
import Confetti from "react-confetti";
import "./Success.css";

const Success = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const sessionId = searchParams.get("session_id");
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  const [showConfetti, setShowConfetti] = useState(true);
  const [dark, setDark] = useState(
    localStorage.getItem("dark") === "true"
  );

  useEffect(() => {
    if (!sessionId) return;

    async function fetchOrder() {
      try {
        const res = await fetch(
          `http://localhost:4000/api/orders/by-session/${sessionId}`
        );
        const data = await res.json();
        if (data.success) setOrder(data.order);
        setLoading(false);
      } catch (err) {
        console.log("Error:", err);
        setLoading(false);
      }
    }
    fetchOrder();
  }, [sessionId]);

  useEffect(() => {
    const timer = setTimeout(() => setShowConfetti(false), 4000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    localStorage.setItem("dark", dark);
  }, [dark]);

  if (loading) {
    return (
      <div className="success-container">
        <div className="success-title">Loading your order...</div>
      </div>
    );
  }

  const statusMap = {
    pending: 30,
    preparing: 55,
    delivering: 80,
    delivered: 100,
  };

  return (
    <div className={`success-container ${dark ? "dark" : ""}`}>
      {showConfetti && <Confetti recycle={false} numberOfPieces={150} />}

     

      <div className="success-animation">
        <DotLottieReact
          src="https://lottie.host/00282d0b-aadf-49c4-a59c-08558f2ffcaf/ViI4pAcmES.lottie"
          loop={false}
          autoplay
        />
      </div>

      <h1 className="success-title">
        Buyurtma muvaffaqiyatli bajarildi! 🎉
      </h1>

      {order && (
        <div className="order-card">
          <h2>🧾 Buyurtma ma’lumotlari</h2>

          <p>
            <span>Order raqami:</span> <br />
            <span className="order-id">#{order._id}</span>
          </p>

          <p>
            <span>To‘lov holati:</span> <br />
            <span className="paid">
              {order.paymentStatus}
            </span>
          </p>

          <p>
            <span>Umumiy summa:</span> <br />$
            {order.totalAmount}
          </p>

          <p>
            <span>Manzil:</span> <br />
            {order.deliveryAddress}
          </p>

          {/* 🚚 PROGRESS */}
          <div className="progress-wrapper">
            <p className="progress-text">
              🚚 Holat: {order.status || "pending"}
            </p>
            <div className="progress-bar">
              <div
                className="progress-fill"
                style={{
                  width: `${statusMap[order.status] || 30}%`,
                }}
              />
            </div>
          </div>

          <h3>🍔 Buyurtma tarkibi:</h3>
          <ul>
            {(order.items || []).map((item, index) => (
              <li key={index}>
                {item.name} — {item.quantity} x $
                {item.price}
              </li>
            ))}
          </ul>
        </div>
      )}

      <button
        onClick={() => navigate("/")}
        className="success-button"
      >
        Bosh sahifaga qaytish
      </button>
    </div>
  );
};

export default Success;
