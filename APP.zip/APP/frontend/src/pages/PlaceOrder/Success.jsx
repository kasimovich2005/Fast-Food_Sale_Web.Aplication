// src/pages/Order/Success.jsx
import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import axios from "axios";

const Success = () => {
  const [searchParams] = useSearchParams();
  const [message, setMessage] = useState("Loading...");
  const sessionId = searchParams.get("session_id");

  useEffect(() => {
    const fetchOrder = async () => {
      try {
        if (!sessionId) {
          setMessage("Invalid session.");
          return;
        }

        // Backend endpoint: bu yerda sessionId asosida orderni tekshiramiz
        const res = await axios.post("http://localhost:4000/api/orders/verify-payment", {
          sessionId,
        });

        if (res.data.success) {
          setMessage("✅ Buyurtma muvaffaqiyatli bajarildi!");
        } else {
          setMessage("❌ Buyurtma tasdiqlanmadi.");
        }
      } catch (err) {
        console.log(err);
        setMessage("❌ Xatolik yuz berdi.");
      }
    };

    fetchOrder();
  }, [sessionId]);

  return (
    <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "80vh", flexDirection: "column" }}>
      <h1>{message}</h1>
      <a href="/" style={{ marginTop: "20px", textDecoration: "underline", color: "blue" }}>
        Bosh sahifaga qaytish
      </a>
    </div>
  );
};

export default Success;
