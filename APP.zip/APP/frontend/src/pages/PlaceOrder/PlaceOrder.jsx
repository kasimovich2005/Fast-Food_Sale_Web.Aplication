import React, { useContext, useState } from "react";
import axios from "axios";
import { StoreContext } from "../../context/StoreContext";
import "./PlaceOrder.css";

const PlaceOrder = () => {
  const { cartItems, food_list, getTotalCartAmount, url, token } = useContext(StoreContext);

  const [deliveryAddress, setDeliveryAddress] = useState({
    firstName: "",
    lastName: "",
    email: "",
    street: "",
    city: "",
    state: "",
    zip: "",
    country: "",
    phone: "",
  });

  const handleChange = (e) => {
    setDeliveryAddress({ ...deliveryAddress, [e.target.name]: e.target.value });
  };

  const isFormValid = () => {
    return Object.keys(deliveryAddress)
    .map((key) => deliveryAddress[key] !== "")
    .every((item) => item)
  }  

  const handleCheckout = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(
        `${url}/api/orders/create-checkout-session`,
        { cartItems, foodList: food_list, deliveryAddress },
        { headers: { token } }
      );
      window.location.href = res.data.url; // Stripe checkoutga redirect
    } catch (error) {
      console.log("Checkout xatoligi:", error);
    }
  };

  return (
    <form className="place-order">
      <div className="place-order-left">
        <p className="title">Yetkazib Berish Haqida Ma'lumot</p>
        {!isFormValid() && (
          <p className="title-red">Ma'lumotlarni to'liq to'ldirgandan so'ng to'lov amalga oshirish mumkin!</p>
        )}
        <div className="multi-fields">
          <input type="text" name="firstName" placeholder="Ism" onChange={handleChange} />
          <input type="text" name="lastName" placeholder="Familya" onChange={handleChange} />
        </div>
        <input type="email" name="email" placeholder="Email" onChange={handleChange} />
        <input type="text" name="street" placeholder="Street" onChange={handleChange} />
        <div className="multi-fields">
          <input type="text" name="city" placeholder="City" onChange={handleChange} />
          <input type="text" name="state" placeholder="State" onChange={handleChange} />
        </div>
        <div className="multi-fields">
          <input type="text" name="zip" placeholder="Zip Code" onChange={handleChange} />
          <input type="text" name="country" placeholder="Country" onChange={handleChange} />
        </div>
        <input type="text" name="phone" placeholder="Phone" onChange={handleChange} />
      </div>

      <div className="place-order-right">
        <div className="cart-total">
          <h2>Jami </h2>
          <div>
            <div className="cart-total-details">
              <p>Taomning narxi</p>
              <p>${getTotalCartAmount()}</p>
            </div>
            <hr />
            <div className="cart-total-details">
              <p>Yetkazib berish </p>
              <p>${getTotalCartAmount() === 0 ? 0 : 2}</p>
            </div>
            <hr />
            <div className="cart-total-details">
              <b>Jami</b>
              <b>${getTotalCartAmount() === 0 ? 0 : getTotalCartAmount() + 2}</b>
            </div>
          </div>
          <button disabled={!isFormValid()} onClick={handleCheckout}>To'lov qilish</button>
        </div>
      </div>
    </form>
  );
};

export default PlaceOrder;
