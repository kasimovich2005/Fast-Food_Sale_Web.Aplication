import React from 'react'
import './Header.css'
const Header = () => {
  return (
    <div className='header'>
      <div className="header-contets">
        <h2>Bu yerda sevimli taomingizga buyurtma bering</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae quisquam repellendus maiores placeat rerum eos culpa, voluptatum nesciunt alias qui.</p>
        <button>Menyuni Ko'rish</button>
      </div>
    </div>
  )
}

export default Header
